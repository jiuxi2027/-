<?php
/**
 * ImgLocalizer 内置管理页（设置 / 环境检测 / 批量处理 / 日志）
 *
 * 使用官方后台框架（admin_header / admin_footer），自带左侧菜单与顶栏。
 */

require_once dirname(__FILE__) . '/../../../zb_system/function/c_system_base.php';
require_once dirname(__FILE__) . '/../../../zb_system/function/c_system_admin.php';

$zbp->Load();

if (!$zbp->CheckPlugin('ImgLocalizer')) {
    $zbp->ShowError(48);
    die();
}
if (!$zbp->CheckRights('admin')) {
    $zbp->ShowError(6);
    die();
}

require_once dirname(__FILE__) . '/include.php';

$cfgName   = 'ImgLocalizer';
$defaults  = ImgLocalizer_DefaultConfig();
$selfUrl   = $zbp->host . 'zb_users/plugin/ImgLocalizer/main.php';
$csrfToken = method_exists($zbp, 'GetCSRFToken') ? $zbp->GetCSRFToken() : '';
$csrfSuffix = $csrfToken !== '' ? '&amp;csrfToken=' . urlencode($csrfToken) : '';

/**
 * 旧版本回退用的来源校验
 */
function ImgLocalizer_AdminCheckReferer()
{
    global $zbp;

    if (!isset($_SERVER['HTTP_REFERER']) || $_SERVER['HTTP_REFERER'] === '') {
        return false;
    }

    $refHost  = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
    $siteHost = parse_url($zbp->host, PHP_URL_HOST);

    return $refHost && $siteHost && strtolower($refHost) === strtolower($siteHost);
}

/**
 * CSRF 验证：优先官方 CheckIsRefererValid（GET/POST 均校验 csrfToken），旧版本回退来源校验
 */
function ImgLocalizer_AdminCheckCsrf()
{
    if (function_exists('CheckIsRefererValid')) {
        CheckIsRefererValid();
        return true;
    }
    return ImgLocalizer_AdminCheckReferer();
}

$notice  = '';
$canSave = false;

/* ---------------- 保存设置 ---------------- */
if (isset($_POST['action']) && $_POST['action'] === 'save') {
    if (ImgLocalizer_AdminCheckCsrf()) {
        $canSave = true;
    } else {
        $notice = '来源校验失败，请从后台正常入口提交。';
    }
}

if ($canSave) {
    $cfg = $zbp->Config($cfgName);

    $cfg->auto_localize = isset($_POST['auto_localize']) ? '1' : '0';
    $cfg->webp          = isset($_POST['webp']) ? '1' : '0';
    $cfg->keep_original = isset($_POST['keep_original']) ? '1' : '0';
    $cfg->drop_srcset   = isset($_POST['drop_srcset']) ? '1' : '0';
    $cfg->ssl_verify    = isset($_POST['ssl_verify']) ? '1' : '0';
    $cfg->by_month      = isset($_POST['by_month']) ? '1' : '0';
    $cfg->only_published = isset($_POST['only_published']) ? '1' : '0';

    $cfg->webp_quality = (string) max(1, min(100, (int) (isset($_POST['webp_quality']) ? $_POST['webp_quality'] : 82)));
    $cfg->max_size     = (string) max(1, min(50, (int) (isset($_POST['max_size']) ? $_POST['max_size'] : 5)));
    $cfg->timeout      = (string) max(3, min(120, (int) (isset($_POST['timeout']) ? $_POST['timeout'] : 15)));
    $cfg->max_per_post = (string) max(0, min(100, (int) (isset($_POST['max_per_post']) ? $_POST['max_per_post'] : 10)));

    $cfg->ext_whitelist = isset($_POST['ext_whitelist'])
        ? trim(preg_replace('/[^a-zA-Z0-9,]/', '', (string) $_POST['ext_whitelist']))
        : $defaults['ext_whitelist'];

    $cfg->host_allow = isset($_POST['host_allow'])
        ? trim(preg_replace('/[^a-zA-Z0-9\.,\-_]/', '', (string) $_POST['host_allow']))
        : '';

    $cfg->host_block = isset($_POST['host_block'])
        ? trim(preg_replace('/[^a-zA-Z0-9\.,\-_]/', '', (string) $_POST['host_block']))
        : '';

    $cfg->version = $defaults['version'];

    $zbp->SaveConfig($cfgName);
    $zbp->SetHint('good');

    Redirect($selfUrl . '?saved=1');
}

/* ---------------- 单篇处理 ---------------- */
if (isset($_GET['do']) && $_GET['do'] === 'one') {
    $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
    $msg = '';

    if (!ImgLocalizer_AdminCheckCsrf()) {
        $msg = '来源校验失败，请从插件管理页操作。';
    } elseif ($id > 0) {
        @set_time_limit(0);

        $article = $zbp->GetPostByID($id);
        if ($article && (int) $article->ID > 0) {
            $before = ImgLocalizer_CountRemote($article->Content);
            $new = ImgLocalizer_LocalizeHtml($article->Content);

            if ($new !== $article->Content) {
                $article->Content = $new;
                $article->Save();
                $after = ImgLocalizer_CountRemote($new);
                $msg = '《' . $article->Title . '》：原有外链图片 ' . $before . ' 张，剩余 ' . $after . ' 张。';
            } else {
                $msg = '《' . $article->Title . '》：没有找到可本地化的外链图片。';
            }
        } else {
            $msg = '文章 ID ' . $id . ' 不存在。';
        }
    } else {
        $msg = '请填写正确的文章 ID。';
    }

    Redirect($selfUrl . '?msg=' . urlencode($msg));
}

/* ---------------- 清空日志 ---------------- */
if (isset($_GET['do']) && $_GET['do'] === 'clearlog') {
    if (ImgLocalizer_AdminCheckCsrf()) {
        @file_put_contents(dirname(__FILE__) . '/log.txt', '');
    }
    Redirect($selfUrl . '?saved=1');
}

if (isset($_GET['saved'])) {
    $notice = '操作已完成。';
}
if (isset($_GET['msg']) && $_GET['msg'] !== '') {
    $notice = (string) $_GET['msg'];
}

/* ---------------- 数据准备 ---------------- */
$v = array();
foreach ($defaults as $key => $value) {
    $v[$key] = ImgLocalizer_Config($key, $value);
}

$checked = function ($key) use ($v) {
    return ((string) $v[$key] === '1') ? ' checked="checked"' : '';
};

$stat = ImgLocalizer_Stat();

/* ---------------- 运行环境检测 ---------------- */
$uploadDir = $zbp->usersdir . 'upload/';

$env = array(
    'php'       => PHP_VERSION,
    'curl'      => function_exists('curl_init'),
    'fopen'     => (bool) ini_get('allow_url_fopen'),
    'gd'        => extension_loaded('gd'),
    'imagewebp' => function_exists('imagewebp'),
    'upload'    => is_dir($uploadDir) ? is_writable($uploadDir) : is_writable($zbp->usersdir),
    'canFetch'  => function_exists('curl_init') || (bool) ini_get('allow_url_fopen'),
);

$envItems = array(
    'php'       => array('PHP 版本（需 7.0+）', $env['php'], version_compare(PHP_VERSION, '7.0.0', '>=')),
    'canFetch'  => array('下载能力（curl 扩展 或 allow_url_fopen，二选一）', $env['curl'] ? 'curl 可用' : ($env['fopen'] ? 'allow_url_fopen 已开启' : '不可用'), $env['canFetch']),
    'imagewebp' => array('GD 扩展 + imagewebp（转 WebP 用，可选）', $env['imagewebp'] ? '支持' : ($env['gd'] ? '有 GD 但不支持 webp' : '未安装 GD'), $env['imagewebp']),
    'upload'    => array('zb_users/upload/ 目录可写', $env['upload'] ? '可写' : '不可写', $env['upload']),
);

$envOk = true;
foreach ($envItems as $item) {
    if ($item[0] !== 'GD 扩展 + imagewebp（转 WebP 用，可选）' && !$item[2]) {
        $envOk = false;
    }
}

$articles = array();
try {
    if (method_exists($zbp, 'GetArticleList')) {
        $articles = $zbp->GetArticleList(
            '*',
            array(array('=', 'log_Type', 0)),
            array('log_PostTime' => 'DESC'),
            30,
            null
        );
    }
} catch (\Throwable $e) {
    $articles = array();
}
if (!is_array($articles)) {
    $articles = array();
}

$logFile = dirname(__FILE__) . '/log.txt';
$logLines = array();
if (is_file($logFile)) {
    $raw = @file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (is_array($raw)) {
        $logLines = array_slice($raw, -15);
    }
}

$blogtitle = '外链图片本地化 - ImgLocalizer';

require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';
?>
<div id="divMain">
    <div class="divHeader"><?php echo $blogtitle; ?></div>
    <div class="SubMenu">
        <a href="<?php echo $selfUrl; ?>"><span class="m-left">设置与工具</span></a>
        <a href="https://docs.zblogcn.com/php/dev-plugin" target="_blank"><span class="m-right">插件文档</span></a>
    </div>
    <div id="divMain2">

        <link rel="stylesheet" href="<?php echo $zbp->host; ?>zb_users/plugin/ImgLocalizer/assets/admin.css?v=1.0.0">

        <?php if ($notice !== '') { ?>
            <div class="ill-notice"><?php echo htmlspecialchars($notice, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php } ?>

        <div class="ill-card">
            <div class="ill-stat">
                <div><span>已缓存图片</span><b><?php echo (int) $stat['files']; ?></b></div>
                <div><span>占用空间</span><b><?php echo round($stat['size'] / 1048576, 2); ?> MB</b></div>
                <div><span>存储目录</span><b style="font-size:13px;font-weight:600;">zb_users/upload/remote/</b></div>
            </div>
            <div class="ill-tips">图片按 URL 的 md5 命名，同一个地址只会下载一次；停用插件不会删除已下载的图片。</div>
        </div>

        <div class="ill-card">
            <div class="ill-row" style="padding-top:2px;">
                <div class="ill-label">运行环境检测</div>
                <div class="ill-ctrl">
                    <ul class="ill-env">
                        <?php foreach ($envItems as $item) { ?>
                            <li>
                                <span class="ill-tag <?php echo $item[2] ? 'ok' : 'no'; ?>"><?php echo $item[2] ? '通过' : '未通过'; ?></span>
                                <?php echo htmlspecialchars($item[0], ENT_QUOTES, 'UTF-8'); ?>
                                <span class="ill-desc"><?php echo htmlspecialchars((string) $item[1], ENT_QUOTES, 'UTF-8'); ?></span>
                            </li>
                        <?php } ?>
                    </ul>
                    <div class="ill-tips">
                        <?php if (!$env['canFetch']) { ?>
                            <span style="color:#c0392b;">无法下载图片：请安装 curl 扩展，或在 php.ini 中开启 allow_url_fopen。</span><br>
                        <?php } ?>
                        <?php if (!$env['imagewebp']) { ?>
                            <span style="color:#b07d2b;">转 WebP 不可用：不影响下载本地化，只是保存原始格式（jpg / png）。需要 PHP 编译 GD 扩展且包含 webp 支持（PHP 7.1+ 的官方包一般自带）。</span><br>
                        <?php } ?>
                        <?php if ($envOk && $env['imagewebp']) { ?>
                            全部条件满足，所有功能可用。
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>

        <form method="post" action="<?php echo $selfUrl; ?>">
            <?php if ($csrfToken !== '') { ?>
                <input type="hidden" name="csrfToken" value="<?php echo $csrfToken; ?>">
            <?php } ?>
            <input type="hidden" name="action" value="save">

            <div class="ill-card">
                <div class="ill-row">
                    <div class="ill-label">自动本地化<small>发布或保存文章时，自动下载正文中的外链图并替换为本站地址</small></div>
                    <div class="ill-ctrl">
                        <label class="ill-switch"><input type="checkbox" name="auto_localize" value="1"<?php echo $checked('auto_localize'); ?>>启用</label>
                        <div class="ill-tips">关闭后只能在本页下方手动逐篇处理，不会再在保存时自动下载。</div>
                    </div>
                </div>

                <div class="ill-row">
                    <div class="ill-label">转 WebP<small>需要 GD 扩展支持 imagewebp；不支持时只下载不转换</small></div>
                    <div class="ill-ctrl">
                        <label class="ill-switch"><input type="checkbox" name="webp" value="1"<?php echo $checked('webp'); ?>>jpg / png 下载后自动转成 webp（体积约省 20%~50%）</label>
                        <?php if (!$env['imagewebp']) { ?>
                            <div class="ill-tips" style="color:#c0392b;">
                                当前服务器不支持 imagewebp，勾选也不会生效。请联系主机商开启 GD 扩展的 webp 支持，或保持关闭。
                            </div>
                        <?php } ?>
                        <div class="ill-tips">
                            质量 <input type="number" name="webp_quality" min="1" max="100" value="<?php echo (int) $v['webp_quality']; ?>">（建议 75~90，越低体积越小）
                            <label class="ill-switch" style="margin-left:14px;"><input type="checkbox" name="keep_original" value="1"<?php echo $checked('keep_original'); ?>>保留原图（转 webp 后不删除 jpg/png）</label>
                        </div>
                    </div>
                </div>

                <div class="ill-row">
                    <div class="ill-label">下载限制<small>防止文章保存过慢</small></div>
                    <div class="ill-ctrl">
                        单图最大 <input type="number" name="max_size" min="1" max="50" value="<?php echo (int) $v['max_size']; ?>"> MB
                        &nbsp;&nbsp;超时 <input type="number" name="timeout" min="3" max="120" value="<?php echo (int) $v['timeout']; ?>"> 秒
                        &nbsp;&nbsp;每篇最多 <input type="number" name="max_per_post" min="0" max="100" value="<?php echo (int) $v['max_per_post']; ?>"> 张
                        <div class="ill-tips">每篇设为 0 表示不自动处理，只能手动逐篇执行。</div>
                    </div>
                </div>

                <div class="ill-row">
                    <div class="ill-label">图片类型<small>按远端返回的 Content-Type 判断，不是看网址后缀；逗号分隔</small></div>
                    <div class="ill-ctrl">
                        <input type="text" name="ext_whitelist" value="<?php echo htmlspecialchars((string) $v['ext_whitelist'], ENT_QUOTES, 'UTF-8'); ?>">
                        <div class="ill-tips">默认 jpg,jpeg,png,gif,webp,bmp。像 svg 这种可能带脚本的格式已被排除，不建议加回来。</div>
                    </div>
                </div>

                <div class="ill-row">
                    <div class="ill-label">域名规则<small>留空表示不限制</small></div>
                    <div class="ill-ctrl">
                        <input type="text" name="host_allow" value="<?php echo htmlspecialchars((string) $v['host_allow'], ENT_QUOTES, 'UTF-8'); ?>" placeholder="只处理这些域名，如 sinaimg.cn,qpic.cn">
                        <div style="margin-top:8px;">
                            <input type="text" name="host_block" value="<?php echo htmlspecialchars((string) $v['host_block'], ENT_QUOTES, 'UTF-8'); ?>" placeholder="跳过这些域名，如 example.com">
                        </div>
                        <div class="ill-tips">本站域名的图片本来就会跳过，不用填。子域名会匹配主域名，如填 sinaimg.cn 也会匹配 img.sinaimg.cn。</div>
                    </div>
                </div>

                <div class="ill-row">
                    <div class="ill-label">其它</div>
                    <div class="ill-ctrl">
                        <label class="ill-switch"><input type="checkbox" name="drop_srcset" value="1"<?php echo $checked('drop_srcset'); ?>>本地化后移除 srcset（不移除的话浏览器可能仍去请求远程图，建议保持开启）</label><br>
                        <label class="ill-switch"><input type="checkbox" name="by_month" value="1"<?php echo $checked('by_month'); ?>>按年月分子目录存放（如 upload/remote/2026/11/，方便按时间清理）</label><br>
                        <label class="ill-switch"><input type="checkbox" name="only_published" value="1"<?php echo $checked('only_published'); ?>>仅处理已发布文章（草稿、待审文章不自动下载）</label><br>
                        <label class="ill-switch"><input type="checkbox" name="ssl_verify" value="1"<?php echo $checked('ssl_verify'); ?>>校验远端 SSL 证书（部分主机证书链不全会导致大面积下载失败，失败时再关）</label>
                    </div>
                </div>

                <div class="ill-actions">
                    <input type="submit" class="button" value="保存设置">
                </div>
            </div>
        </form>

        <div class="ill-card">
            <div class="ill-row" style="padding-top:2px;">
                <div class="ill-label">历史文章处理<small>只对安装后新保存的文章自动生效</small></div>
                <div class="ill-ctrl">
                    <form method="get" action="<?php echo $selfUrl; ?>" class="ill-inline-form" style="margin-top:0;">
                        <input type="hidden" name="do" value="one">
                        <?php if ($csrfToken !== '') { ?>
                            <input type="hidden" name="csrfToken" value="<?php echo $csrfToken; ?>">
                        <?php } ?>
                        <input type="number" name="id" min="1" placeholder="文章 ID" class="ill-id-input">
                        <input type="submit" class="button" value="处理这一篇">
                    </form>
                    <div class="ill-tips" style="margin-top:0;">处理时会下载图片并更新正文，请先备份数据库。列出最近 30 篇：</div>

                    <?php if (count($articles) === 0) { ?>
                        <div class="ill-tips" style="margin-top:10px;">没有读取到文章列表，可以直接用上面的文章 ID 逐篇处理。</div>
                    <?php } else { ?>
                        <table class="ill-table">
                            <thead>
                            <tr><th style="width:70px;">ID</th><th>标题</th><th style="width:110px;">外链图片</th><th style="width:90px;">操作</th></tr>
                            </thead>
                            <tbody>
                            <?php foreach ($articles as $a) {
                                if (!is_object($a)) {
                                    continue;
                                }
                                $remote = ImgLocalizer_CountRemote($a->Content);
                                ?>
                                <tr>
                                    <td><?php echo (int) $a->ID; ?></td>
                                    <td>
                                        <?php echo htmlspecialchars((string) $a->Title, ENT_QUOTES, 'UTF-8'); ?>
                                        <div class="ill-muted"><?php echo htmlspecialchars((string) $a->Time, ENT_QUOTES, 'UTF-8'); ?></div>
                                    </td>
                                    <td><?php echo $remote > 0 ? '<span class="ill-num">' . $remote . '</span>' : '<span class="ill-muted">0</span>'; ?></td>
                                    <td>
                                        <?php if ($remote > 0) { ?>
                                            <a class="button" href="<?php echo $selfUrl; ?>?do=one&amp;id=<?php echo (int) $a->ID . $csrfSuffix; ?>">本地化</a>
                                        <?php } else { ?>
                                            <span class="ill-muted">无需处理</span>
                                        <?php } ?>
                                    </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    <?php } ?>
                </div>
            </div>
        </div>

        <div class="ill-card">
            <div class="ill-row" style="padding-top:2px;">
                <div class="ill-label">运行日志<small>超过 200 KB 自动清空</small></div>
                <div class="ill-ctrl">
                    <?php if (count($logLines) === 0) { ?>
                        <div class="ill-tips">暂无日志。</div>
                    <?php } else { ?>
                        <pre class="ill-log"><?php echo htmlspecialchars(implode(PHP_EOL, $logLines), ENT_QUOTES, 'UTF-8'); ?></pre>
                    <?php } ?>
                    <a class="button" href="<?php echo $selfUrl; ?>?do=clearlog<?php echo $csrfSuffix; ?>" onclick="return confirm('确定清空运行日志吗？');">清空日志</a>
                </div>
            </div>
        </div>

    </div>
</div>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
if (function_exists('RunTime')) {
    RunTime();
}
