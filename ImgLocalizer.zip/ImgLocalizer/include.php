<?php
if (!defined('ZBP_PATH')) {
    exit;
}
/**
 * ImgLocalizer - 外链图片本地化插件核心逻辑
 *
 * 功能：
 *  1. 文章发布 / 保存时，自动把正文里的外链图片下载到本地，替换为本站地址
 *  2. 相同 URL 只下载一次（md5 命名缓存）
 *  3. 可选转 WebP 压缩（需 GD 支持）
 *  4. 后台可对历史文章逐篇补处理
 *
 * 安全：拒绝内网 / 保留地址，限制单图体积与数量，校验 Content-Type 与图片有效性。
 */

RegisterPlugin('ImgLocalizer', 'ActivePlugin_ImgLocalizer');

/**
 * 注册钩子
 */
function ActivePlugin_ImgLocalizer()
{
    static $registered = false;
    if ($registered) {
        return;
    }
    $registered = true;

    Add_Filter_Plugin('Filter_Plugin_Article_Post', 'ImgLocalizer_Filter_ArticlePost');
    Add_Filter_Plugin('Filter_Plugin_Article_Save', 'ImgLocalizer_Filter_ArticlePost');
}

/**
 * 默认配置
 */
function ImgLocalizer_DefaultConfig()
{
    return array(
        'version'       => '1.0.0',
        'auto_localize' => '1',   // 发布/保存时自动本地化
        'webp'          => '0',   // 转 WebP
        'webp_quality'  => '82',
        'keep_original' => '0',   // 转 WebP 后保留原图
        'max_size'      => '5',   // 单图体积上限（MB）
        'timeout'       => '15',  // 下载超时（秒）
        'max_per_post'  => '10',  // 每篇最多处理张数
        'drop_srcset'   => '1',   // 本地化后移除 srcset，避免继续走远程
        'ssl_verify'    => '0',   // 校验远端 SSL 证书
        'by_month'      => '0',   // 按年月分子目录存放
        'ext_whitelist' => 'jpg,jpeg,png,gif,webp,bmp',
        'host_allow'    => '',    // 仅处理这些域名（逗号分隔，留空=全部）
        'host_block'    => '',    // 跳过这些域名（逗号分隔）
        'only_published' => '0',  // 仅处理已发布状态的文章
    );
}

/**
 * 读取配置
 */
function ImgLocalizer_Config($key, $default = '')
{
    global $zbp;

    $defaults = ImgLocalizer_DefaultConfig();
    $fallback = isset($defaults[$key]) ? $defaults[$key] : $default;

    $cfg = $zbp->Config('ImgLocalizer');
    if (is_object($cfg)) {
        $value = $cfg->$key;
        if ($value !== null && $value !== '') {
            return $value;
        }
    }

    return $fallback;
}

/**
 * 文章保存钩子
 *
 * @param object $article Post 对象
 */
function ImgLocalizer_Filter_ArticlePost($article = null)
{
    static $busy = false;

    if ($busy || !is_object($article)) {
        return;
    }
    if (!(bool) ImgLocalizer_Config('auto_localize')) {
        return;
    }
    if (!isset($article->Content) || $article->Content === '') {
        return;
    }
    if ((bool) ImgLocalizer_Config('only_published') && (int) $article->Status !== 1) {
        return;
    }

    $busy = true;
    $new = ImgLocalizer_LocalizeHtml($article->Content);
    if ($new !== $article->Content) {
        $article->Content = $new;
    }
    $busy = false;
}

/**
 * 本地化一段 HTML 中的外链图片
 *
 * @param string $html
 * @return string
 */
function ImgLocalizer_LocalizeHtml($html)
{
    if (!is_string($html) || $html === '' || stripos($html, '<img') === false) {
        return $html;
    }

    $max = (int) ImgLocalizer_Config('max_per_post');
    if ($max <= 0) {
        $max = 10;
    }
    $dropSrcset = (bool) ImgLocalizer_Config('drop_srcset');

    $done = 0;

    $result = preg_replace_callback(
        '#<img\b[^>]*>#i',
        function ($m) use (&$done, $max, $dropSrcset) {
            $tag = $m[0];
            if ($done >= $max) {
                return $tag;
            }

            $changed = false;
            $attrs = array('src', 'data-src', 'data-original', 'data-lazy-src');

            foreach ($attrs as $attr) {
                $pattern = '#\s' . $attr . '\s*=\s*(["\'])([^"\']*)\1#is';
                if (!preg_match($pattern, $tag, $am)) {
                    continue;
                }
                $url = htmlspecialchars_decode($am[2], ENT_QUOTES);
                $local = ImgLocalizer_LocalizeUrl($url);
                if ($local === false || $local === $url) {
                    continue;
                }
                $tag = str_replace($am[0], ' ' . $attr . '="' . $local . '"', $tag);
                $changed = true;
            }

            if ($changed) {
                $done++;
                if ($dropSrcset && preg_match('#\ssrcset\s*=\s*(["\'])([^"\']*)\1#is', $tag, $sm)) {
                    $tag = str_replace($sm[0], '', $tag);
                }
            }

            return $tag;
        },
        $html
    );

    return $result === null ? $html : $result;
}

/**
 * 把单个远程图片地址转成本地地址
 */
function ImgLocalizer_LocalizeUrl($url)
{
    global $zbp;

    $url = trim($url);
    if ($url === '' || strpos($url, 'data:') === 0 || strpos($url, 'blob:') === 0) {
        return false;
    }
    if (strpos($url, '//') === 0) {
        $url = 'https:' . $url;
    }
    if (!preg_match('#^https?://#i', $url)) {
        return false;
    }

    $url = str_replace(' ', '%20', $url);

    $host = strtolower((string) parse_url($url, PHP_URL_HOST));
    if ($host === '') {
        return false;
    }

    $siteHost = strtolower((string) parse_url($zbp->host, PHP_URL_HOST));
    if ($host === $siteHost || $host === 'www.' . $siteHost || 'www.' . $host === $siteHost) {
        return false;
    }

    $block = trim((string) ImgLocalizer_Config('host_block'));
    if ($block !== '') {
        foreach (preg_split('/[\s,]+/', $block) as $item) {
            if ($item !== '' && stripos($host, strtolower($item)) !== false) {
                return false;
            }
        }
    }

    $allow = trim((string) ImgLocalizer_Config('host_allow'));
    if ($allow !== '') {
        $matched = false;
        foreach (preg_split('/[\s,]+/', $allow) as $item) {
            if ($item !== '' && stripos($host, strtolower($item)) !== false) {
                $matched = true;
                break;
            }
        }
        if (!$matched) {
            return false;
        }
    }

    if (ImgLocalizer_IsPrivateHost($host)) {
        ImgLocalizer_Log('拒绝内网地址: ' . $url);
        return false;
    }

    $st = ImgLocalizer_StorageDir();
    if ($st === false) {
        ImgLocalizer_Log('上传目录不可写: ' . $zbp->usersdir . 'upload/');
        return false;
    }

    $cached = ImgLocalizer_FindCached($st, $url);
    if ($cached !== false) {
        return $cached;
    }

    $saved = ImgLocalizer_Download($url, $st);
    if ($saved === false) {
        return false;
    }

    if ((bool) ImgLocalizer_Config('webp')) {
        $webpFile = ImgLocalizer_ToWebp($saved['file'], $saved['ext']);
        if ($webpFile !== false) {
            $saved['file'] = $webpFile;
            $saved['url'] = ImgLocalizer_BuildUrl($st['rel'], basename($webpFile));
        }
    }

    return $saved['url'];
}

/**
 * 拒绝内网 / 保留地址（基础 SSRF 防护）
 */
function ImgLocalizer_IsPrivateHost($host)
{
    $host = strtolower($host);

    if ($host === 'localhost' || substr($host, -6) === '.local') {
        return true;
    }

    $ip = filter_var($host, FILTER_VALIDATE_IP);
    if ($ip === false) {
        $resolved = @gethostbyname($host);
        if ($resolved === $host) {
            return false; 
        }
        $ip = $resolved;
    }

    $public = filter_var(
        $ip,
        FILTER_VALIDATE_IP,
        FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
    );

    return $public === false;
}

/**
 * 存储目录信息
 *

 */
function ImgLocalizer_StorageDir()
{
    global $zbp;

    $rel = 'upload/remote/';
    if ((bool) ImgLocalizer_Config('by_month')) {
        $rel .= date('Y') . '/' . date('m') . '/';
    }

    $abs = $zbp->usersdir . $rel;
    if (!is_dir($abs)) {
        @mkdir($abs, 0755, true);
    }

    if (!is_dir($abs) || !is_writable($abs)) {
        return false;
    }

    return array('abs' => $abs, 'rel' => $rel);
}

/**
 * 拼接本地 URL
 */
function ImgLocalizer_BuildUrl($relDir, $name)
{
    global $zbp;

    return $zbp->host . 'zb_users/' . $relDir . $name;
}

/**
 * 查找已下载过的同一 URL
 *
 */
function ImgLocalizer_FindCached($st, $url)
{
    $base = md5($url);
    foreach (array('jpg', 'png', 'gif', 'webp', 'bmp') as $ext) {
        $file = $st['abs'] . $base . '.' . $ext;
        if (is_file($file)) {
            return ImgLocalizer_BuildUrl($st['rel'], $base . '.' . $ext);
        }
    }

    return false;
}

/**
 * 根据 Content-Type / URL 判断扩展名
 *
 */
function ImgLocalizer_ExtFromType($contentType, $url)
{
    $map = array(
        'image/jpeg'      => 'jpg',
        'image/jpg'       => 'jpg',
        'image/pjpeg'     => 'jpg',
        'image/png'       => 'png',
        'image/x-png'     => 'png',
        'image/gif'       => 'gif',
        'image/webp'      => 'webp',
        'image/bmp'       => 'bmp',
        'image/x-ms-bmp'  => 'bmp',
    );

    $ext = '';
    if ($contentType !== '') {
        $type = strtolower(trim(preg_replace('#;.*$#', '', $contentType)));
        if (isset($map[$type])) {
            $ext = $map[$type];
        }
    }

    if ($ext === '') {
        $path = (string) parse_url($url, PHP_URL_PATH);
        $guess = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if (in_array($guess, array('jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'), true)) {
            $ext = ($guess === 'jpeg') ? 'jpg' : $guess;
        }
    }

    if ($ext === '') {
        return false;
    }

    $whitelist = strtolower((string) ImgLocalizer_Config('ext_whitelist'));
    if ($whitelist !== '') {
        $list = array_map('trim', explode(',', $whitelist));
        if (!in_array($ext, $list, true) && !($ext === 'jpg' && in_array('jpeg', $list, true))) {
            return false;
        }
    }

    return $ext;
}

/**
 * 下载远程图片
 *
 */
function ImgLocalizer_Download($url, $st)
{
    $maxBytes = max(1, (int) ImgLocalizer_Config('max_size')) * 1024 * 1024;
    $timeout  = max(3, (int) ImgLocalizer_Config('timeout'));
    $verify   = (bool) ImgLocalizer_Config('ssl_verify');
    $ua       = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

    $body  = false;
    $ctype = '';

    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 8);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_USERAGENT, $ua);
        curl_setopt($ch, CURLOPT_REFERER, $url);
        if (!$verify) {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        }
        $body = curl_exec($ch);
        if ($body === false) {
            ImgLocalizer_Log('curl 失败: ' . curl_error($ch) . ' ' . $url);
            curl_close($ch);
            return false;
        }
        $ctype = (string) curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        $code  = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($code >= 400 || $code === 0) {
            ImgLocalizer_Log('HTTP ' . $code . ' ' . $url);
            return false;
        }
    } else {
        $ctx = stream_context_create(array(
            'http' => array(
                'timeout'         => $timeout,
                'user_agent'      => $ua,
                'follow_location' => 1,
                'max_redirects'   => 3,
            ),
            'ssl'  => array(
                'verify_peer'      => $verify,
                'verify_peer_name' => $verify,
            ),
        ));

        $body = @file_get_contents($url, false, $ctx, 0, $maxBytes + 1024);
        if ($body === false) {
            ImgLocalizer_Log('请求失败: ' . $url);
            return false;
        }

        if (isset($http_response_header) && is_array($http_response_header)) {
            foreach ($http_response_header as $header) {
                if (stripos($header, 'content-type:') === 0) {
                    $ctype = trim(substr($header, 13));
                }
            }
        }
    }

    if ($body === false || strlen($body) < 12) {
        ImgLocalizer_Log('内容为空或过短: ' . $url);
        return false;
    }

    if (strlen($body) > $maxBytes) {
        ImgLocalizer_Log('超过体积上限: ' . $url);
        return false;
    }

    $ext = ImgLocalizer_ExtFromType($ctype, $url);
    if ($ext === false) {
        ImgLocalizer_Log('不允许的图片类型(' . $ctype . '): ' . $url);
        return false;
    }

    $name = md5($url) . '.' . $ext;
    $dest = $st['abs'] . $name;
    $tmp  = $dest . '.part';

    if (@file_put_contents($tmp, $body) === false) {
        ImgLocalizer_Log('写入失败，请检查目录权限: ' . $st['abs']);
        return false;
    }

    $info = @getimagesize($tmp);
    if (!$info || empty($info[0]) || empty($info[1])) {
        @unlink($tmp);
        ImgLocalizer_Log('不是有效图片: ' . $url);
        return false;
    }

    if (!@rename($tmp, $dest)) {
        @unlink($tmp);
        ImgLocalizer_Log('重命名失败: ' . $dest);
        return false;
    }

    @chmod($dest, 0644);

    return array(
        'file' => $dest,
        'ext'  => $ext,
        'url'  => ImgLocalizer_BuildUrl($st['rel'], $name),
    );
}

/**
 * 转 WebP
 *
 */
function ImgLocalizer_ToWebp($file, $ext)
{
    if (!function_exists('imagewebp') || !function_exists('imagecreatefromstring')) {
        return false;
    }
    if (!in_array($ext, array('jpg', 'png'), true)) {
        return false;
    }

    $data = @file_get_contents($file);
    if ($data === false) {
        return false;
    }

    $image = @imagecreatefromstring($data);
    if (!$image) {
        return false;
    }

    $quality = (int) ImgLocalizer_Config('webp_quality');
    $quality = max(1, min(100, $quality ? $quality : 82));

    $target = preg_replace('#\.[a-z0-9]+$#i', '.webp', $file);
    $ok = @imagewebp($image, $target, $quality);
    imagedestroy($image);

    if ($ok && is_file($target) && filesize($target) > 0) {
        if (!(bool) ImgLocalizer_Config('keep_original')) {
            @unlink($file);
        }
        return $target;
    }

    if (is_file($target)) {
        @unlink($target);
    }

    return false;
}

/**
 * 统计一段 HTML 里的外链图片数量
 */
function ImgLocalizer_CountRemote($html)
{
    if (!is_string($html) || $html === '' || stripos($html, '<img') === false) {
        return 0;
    }

    $count = 0;
    if (preg_match_all('#<img\b[^>]*>#i', $html, $matches)) {
        foreach ($matches[0] as $tag) {
            if (preg_match('#\ssrc\s*=\s*(["\'])(https?:)?//#i', $tag)) {
                $count++;
            }
        }
    }

    return $count;
}

/**
 * 本地已缓存图片统计
 */
function ImgLocalizer_Stat()
{
    global $zbp;

    $dir = $zbp->usersdir . 'upload/remote/';
    $stat = array('files' => 0, 'size' => 0);

    if (!is_dir($dir)) {
        return $stat;
    }

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS)
    );

    foreach ($iterator as $file) {
        if ($file->isFile() && $file->getExtension() !== 'part') {
            $stat['files']++;
            $stat['size'] += $file->getSize();
        }
    }

    return $stat;
}

/**
 * 写日志
 */
function ImgLocalizer_Log($message)
{
    $file = dirname(__FILE__) . '/log.txt';

    if (is_file($file) && filesize($file) > 200 * 1024) {
        @file_put_contents($file, '');
    }

    @file_put_contents($file, '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL, FILE_APPEND);
}

/**
 * 启用插件
 */
function InstallPlugin_ImgLocalizer()
{
    global $zbp;

    if (!$zbp->HasConfig('ImgLocalizer')) {
        $cfg = $zbp->Config('ImgLocalizer');
        foreach (ImgLocalizer_DefaultConfig() as $key => $value) {
            $cfg->$key = $value;
        }
        $zbp->SaveConfig('ImgLocalizer');

        $dir = $zbp->usersdir . 'upload/remote/';
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
    }
}

/**
 * 停用插件（保留配置与已下载图片）
 */
function UninstallPlugin_ImgLocalizer()
{
}
